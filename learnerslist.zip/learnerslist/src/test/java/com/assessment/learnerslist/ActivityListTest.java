package com.assessment.learnerslist;

import java.util.ArrayList;

import static org.junit.Assert.*;

public class ActivityListTest {

    ActivityList acts = new ActivityList();
    LearnersList learn = new LearnersList("Ronelle", 10);

    //check if all topics initialized can be chosen
    @org.junit.Test
    public void add() {
        acts.getActList().clear();
         ActivityList act1 = new ActivityList("Concurrency");
         ActivityList act2 = new ActivityList("Naming Convention");
         ActivityList act3 = new ActivityList("Generics");
         ActivityList act4 = new ActivityList("OOP");
         ActivityList act5 = new ActivityList("Termination");

        ArrayList<String> allActivities = new ArrayList<String>() {
            {
                add("Concurrency");
                add("Naming Convention");
                add("Generics");
                add("OOP");
                add("Termination");
            }
        };

        assertEquals(allActivities , acts.getActList());
        System.out.println("LIST OF ACTIVITIES: " + acts.getActList());


    }

    //check what if there is no topics to be chosen
   // @org.junit.Test
//    public void addWithNoTopicsToBeChoose() {
//        acts.getActList().clear();
//
//        ArrayList<String> owws = new ArrayList<String>();
//
//        assertEquals(owws , acts.getActList());
//        System.out.println("NO TOPICS/ACTIVITY TO BE CHOSEN");
//
//    }

    @org.junit.Test
    public void addToListTest() {
        acts.getChosenActivity().clear();
        acts.getActList().clear();

        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("lambda");
        ActivityList act3 = new ActivityList("Naming Conventions");
        ActivityList act4 = new ActivityList("Generics");
        ActivityList act5 = new ActivityList("OOP");
        acts.getChosenActivity().add(acts.getActList().get(0));
        acts.getChosenActivity().add(acts.getActList().get(2));

        ArrayList<String> allChosenActivities = new ArrayList<String>() {
            {
                add("Concurrency");
                add("Naming Conventions");
            }
        };
        assertEquals(allChosenActivities,acts.getChosenActivity());

        System.out.println("YOU CHOOSE:  " + allChosenActivities);


    }
    @org.junit.Test
    public void addToListWithActivityAlreadyExistTest() {
        acts.getChosenActivity().clear();
        acts.getActList().clear();

        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("lambda");
        ActivityList act3 = new ActivityList("Naming Conventions");
        ActivityList act4 = new ActivityList("Generics");
        ActivityList act5 = new ActivityList("OOP");
        acts.getChosenActivity().add(acts.getActList().get(0));
        acts.getChosenActivity().add(acts.getActList().get(2));


        if(acts.getChosenActivity().contains(acts.getActList().get(2))){
            System.out.println("Activity Already added");
        }else{
            System.out.println("WRONG TEST");
        }

        ArrayList<String> allChosenActivities = new ArrayList<String>() {
            {
                add("Concurrency");
                add("Naming Conventions");
            }
        };
        assertEquals(allChosenActivities,acts.getChosenActivity());

        System.out.println("YOU CHOOSE:  " + allChosenActivities);


    }
    @org.junit.Test
    public void addToListWithAddedAllActivityTest() {
        acts.getChosenActivity().clear();
        acts.getActList().clear();

        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("lambda");
        ActivityList act3 = new ActivityList("Naming Conventions");
        ActivityList act4 = new ActivityList("Generics");
        ActivityList act5 = new ActivityList("OOP");
        acts.getChosenActivity().add(acts.getActList().get(0));
        acts.getChosenActivity().add(acts.getActList().get(1));
        acts.getChosenActivity().add(acts.getActList().get(2));
        acts.getChosenActivity().add(acts.getActList().get(3));
        acts.getChosenActivity().add(acts.getActList().get(4));


        if(acts.getChosenActivity().contains(acts.getActList().get(0))
                && acts.getChosenActivity().contains(acts.getActList().get(1))
                && acts.getChosenActivity().contains(acts.getActList().get(2))
                && acts.getChosenActivity().contains(acts.getActList().get(3))
                && acts.getChosenActivity().contains(acts.getActList().get(4))){

            System.out.println("ADDED ALL TOPICS");
        }else{
            System.out.println("Wrong TEST");
        }

        ArrayList<String> allChosenActivities = new ArrayList<String>() {
            {
                add("Concurrency");
                add("lambda");
                add("Naming Conventions");
                add("Generics");
                add("OOP");
            }
        };
        assertEquals(allChosenActivities,acts.getChosenActivity());

        System.out.println("YOU CHOOSE:  " + allChosenActivities);


    }
    //check if the total minute per activity is correct
    @org.junit.Test
    public void totalHoursTest() {

        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("Naming Convention");
        ActivityList act3 = new ActivityList("Generics");
        ActivityList act4 = new ActivityList("OOP");
        ActivityList act5 = new ActivityList("Termination");
        acts.getChosenActivity().add(acts.getActList().get(0));
        acts.getChosenActivity().add(acts.getActList().get(2));


        assertEquals(300, acts.totalHours(learn.getHours()));
        System.out.println(acts.totalHours(learn.getHours()));

    }

    //check if all printed data are reliable
    @org.junit.Test
    public void printTest() {
        acts.getChosenActivity().clear();
        acts.getActList().clear();
        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("Naming Convention");
        ActivityList act3 = new ActivityList("Generics");
        ActivityList act4 = new ActivityList("OOP");
        ActivityList act5 = new ActivityList("Termination");

        ArrayList<String> owws = new ArrayList<String>() {
            {
                add("Concurrency");
                add("OOP");
                add("Termination");
            }
        };
        acts.getChosenActivity().add(acts.getActList().get(0));
        acts.getChosenActivity().add(acts.getActList().get(3));
        acts.getChosenActivity().add(acts.getActList().get(4));

        //check if getting the right name
        assertEquals("Ronelle", learn.getName());

        System.out.println("Name: " + learn.getName());
        System.out.println("----------------------");

        //check if getting the chosen activity/topic
        assertEquals(owws, acts.getChosenActivity());

        System.out.println("Current Activities:");

        for(String cuurAct : acts.getChosenActivity()) {
            System.out.println("*" + cuurAct);
        }

        //check if getting the total hours
        assertEquals(200, acts.totalHours(learn.getHours()));


        System.out.println("----------------------");
        System.out.println("Total minute per Activity");
        System.out.println(acts.totalHours(learn.getHours()));

    }

    //check if all printed data are reliable
    @org.junit.Test
    public void printNoChosenActivityTest() {
        acts.getChosenActivity().clear();
        acts.getActList().clear();
        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("Naming Convention");
        ActivityList act3 = new ActivityList("Generics");
        ActivityList act4 = new ActivityList("OOP");
        ActivityList act5 = new ActivityList("Termination");

        ArrayList<String> owws = new ArrayList<String>();


       System.out.println("** NO TOPICS CHOSEN INVALID DATA **");
        //check if getting the chosen activity/topic
        assertEquals(owws, acts.getChosenActivity());



    }
}