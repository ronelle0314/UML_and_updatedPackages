package com.assessment.bootcampbatchdetails;

import com.assessment.newlearners.LearnersList;
import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import static org.junit.Assert.*;

public class BootCampBatchDetailsTest {

    @Test
    public void bootCampDetailsNoErrorsTest() {
        BootCampBatchDetails batch1 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 4);
        BootCampBatchDetails batch = new BootCampBatchDetails();

        List<BootCampBatch> listOfBatch = new ArrayList<>();

        listOfBatch.add(new BootCampBatch(1,"02/19/2019","04/02/2019",14,4,28.57143f,10,71.42857f));


//        for(BootCampBatch actual : batch.bootCampDetails()){
//            for(BootCampBatch expected : listOfBatch){
//
//                assertEquals(expected.getBatchNumber(), actual.getBatchNumber());
//
//                assertEquals(expected.getStartDate(), actual.getStartDate());
//
//                assertEquals(expected.getEndDate(), actual.getEndDate());
//
//                assertEquals(expected.getNoOfLearners(), actual.getNoOfLearners());
//
//                assertEquals(expected.getNoOfPassers(), actual.getNoOfPassers());
//
//                assertEquals((int)expected.getPassingRate(), (int)actual.getPassingRate());
//
//                assertEquals(expected.getNoOfFailure(), actual.getNoOfFailure());
//
//                assertEquals((int)expected.getFailureRate(), (int)actual.getFailureRate());
//            }
//        }
        assertEquals(listOfBatch, batch.bootCampDetails());
    }

    @Test
    public void bootCampDetailsWithNumberOfPasserIsGreaterNumberOfLearnerTest() {

        BootCampBatchDetails batch1 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 4);
        BootCampBatchDetails batch2 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 15);

        BootCampBatchDetails batch = new BootCampBatchDetails();

        List<BootCampBatch> listOfBatch = new ArrayList<>();

        listOfBatch.add(new BootCampBatch(1,"02/19/2019","04/02/2019",14,4,28.57143f,10,71.42857f));

        assertEquals(listOfBatch, batch.bootCampDetails());
    }
    @Test
    public void bootCampDetailsWithNegativeNumberOfPassersTest() {

        BootCampBatchDetails batch1 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 4);
        BootCampBatchDetails batch2 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, -1);

        BootCampBatchDetails batch = new BootCampBatchDetails();

        List<BootCampBatch> listOfBatch = new ArrayList<>();

        listOfBatch.add(new BootCampBatch(1,"02/19/2019","04/02/2019",14,4,28.57143f,10,71.42857f));

        assertEquals(listOfBatch, batch.bootCampDetails());
    }
    @Test
    public void createReportTest() {
        BootCampBatchDetails batch1 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 4);
        BootCampBatchDetails batch2 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 1);

        BootCampBatchDetails batch = new BootCampBatchDetails();

        //EXPECTED LIST
        List<BootCampBatch> expectedBatch = new ArrayList<>();

        //ACTUAL LIST
        List<BootCampBatch> actualBatch = new ArrayList<>();

        expectedBatch.add(new BootCampBatch(1,"02/19/2019","04/02/2019",14,4,28.57143f,10,71.42857f));
        expectedBatch.add(new BootCampBatch(1,"02/19/2019","04/02/2019",14,1,7.1428576f,13,92.85714f));

        //This will call the report method
        batch.createReport(batch.bootCampDetails());

        //need to read the file
        File existingLearner = new File("BootCampBatchDetails.csv");



        try {

            Scanner scanTestFile = new Scanner(existingLearner);
            if (scanTestFile.hasNext()) {
                while (scanTestFile.hasNext()) {
                    String dataOfNewLearners = scanTestFile.next();

                    String[] values = dataOfNewLearners.split(",");

                    int batchNumber = Integer.parseInt(values[0]);
                    int noOfLearners = Integer.parseInt(values[3]);
                    int noOfPassers = Integer.parseInt(values[4]);
                    float passingRate = Float.parseFloat(values[5]);
                    int noOfFailure = Integer.parseInt(values[6]);
                    float failureRate = Float.parseFloat(values[7]);

                    //trial.add(values[0] + " " + batch);
                    actualBatch.add(new BootCampBatch(batchNumber, values[1], values[2], noOfLearners, noOfPassers, passingRate, noOfFailure, failureRate));

                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        assertEquals(expectedBatch, actualBatch);
    }

}