package com.assessment.demorandomizer;

import org.junit.Assert;
import org.junit.Test;
import org.omg.PortableServer.LIFESPAN_POLICY_ID;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import static org.junit.Assert.*;

public class DemoRandomizerTest {
   DemoRandomizer demo = new DemoRandomizer();
   LearnersList learn = new LearnersList();

    @Test
    public void readFileTest() {
        List<LearnersList> expectedList = new ArrayList<LearnersList>() {};
        List<LearnersList> actualList = new ArrayList<>();

        expectedList.add(new LearnersList("ronelle.s.nolasco", "present", 0));
        for(LearnersList learn : demo.readFile("test.csv", 4))
        {
            actualList.add(new LearnersList(learn.getEID(),learn.getStatus(), learn.getLateTime()));
        }
        assertEquals(expectedList, actualList);
    }

    @Test
    public void readFileWithNoPresentLearnerTest() {
        List<LearnersList> expectedList = new ArrayList<LearnersList>() {};
        List<LearnersList> actualList = new ArrayList<>();


        for(LearnersList learn : demo.readFile("test.csv", 4))
        {
            actualList.add(new LearnersList(learn.getEID(),learn.getStatus(), learn.getLateTime()));
        }
        assertEquals(expectedList, actualList);
    }
    @Test
    public void readFileWithAbsentLearnerTest() {
        List<LearnersList> expectedList = new ArrayList<LearnersList>() {};
        List<LearnersList> actualList = new ArrayList<>();

        expectedList.add(new LearnersList("mark.f.v.macandile", "present", 0));
        for(LearnersList learn : demo.readFile("test.csv", 1))
        {
            actualList.add(new LearnersList(learn.getEID(),learn.getStatus(), learn.getLateTime()));

        }
        assertEquals(expectedList, actualList);
    }
    @Test
    public void readFileWithLateLearnerTest() {

        List<LearnersList> expectedList = new ArrayList<LearnersList>() {};
        List<LearnersList> actualList = new ArrayList<>();

        expectedList.add(new LearnersList("ronelle.s.nolasco", "present", 40, 20));
        for(LearnersList learn : demo.readFile("test.csv", 1))
        {
            actualList.add(new LearnersList(learn.getEID(),learn.getStatus(), learn.getLateTime(), learn.getTimeForDemo()));

        }
        assertNotEquals(expectedList, actualList);

    }



    @Test
    public void totalDemoTimeTest() {
        demo.readFile("test.csv", 4);
        assertEquals(120,  demo.totalDemoTime(4));

    }

    @Test
    public void printTest() {

        List<LearnersList> expectedList = new ArrayList<LearnersList>() {};
        List<LearnersList> actualList = new ArrayList<>();

        expectedList.add(new LearnersList("ronelle.s.nolasco", "present", 0, 60));
        expectedList.add(new LearnersList("mark.f.v.macandile", "present", 0, 60));
        expectedList.add(new LearnersList("nikolai.de.jesus", "present", 0, 60));
        expectedList.add(new LearnersList("daniel.j.a.barrion", "present", 0, 60));

        for(LearnersList learn : demo.readFile("test.csv", 4))
        {
            actualList.add(new LearnersList(learn.getEID(),learn.getStatus(), learn.getLateTime(), learn.getTimeForDemo()));

        }

        assertEquals(expectedList, actualList);
    }
    }
