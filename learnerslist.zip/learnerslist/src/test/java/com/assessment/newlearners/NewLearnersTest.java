package com.assessment.newlearners;

import org.junit.Test;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;

import static org.junit.Assert.*;

public class NewLearnersTest {
    NewLearners nL = new NewLearners();
    LearnersList lL = new LearnersList();

    @Test
    public void readFileTest() throws FileNotFoundException {
        HashSet<LearnersList> hash = new HashSet<>();
        hash.add(new LearnersList("ronelle.s.nolasco", 1));
        hash.add(new LearnersList("mark.f.v.macandile", 1));


        assertEquals(hash, nL.readFile("test.csv", "existingLearners.csv", 10));

    }
    @Test
    public void readFileWithNewLearnersAlreadyExistInExistingLearnersTest() throws FileNotFoundException {
        HashSet<LearnersList> hash = new HashSet<>();
        hash.add(new LearnersList("ronelle.s.nolasco", 1));
        hash.add(new LearnersList("mark.f.v.macandile", 1));


        assertEquals(hash, nL.readFile("test.csv", "existingLearners.csv", 10));

    }
    @Test
    public void readFileWithNoDataToReadTest() throws FileNotFoundException {

        assertEquals(null, nL.readFile("test.csv", "existingLearners.csv", 10));
    }
    @Test(expected = FileNotFoundException.class)
    public void readFileWithInvalidFileFormatTest() throws FileNotFoundException {
        nL.readFile("test.csv", "existingLearners.csv", 10);

    }
    @Test
    public void readFileThatExceedsToMaximumSlotsTest() throws FileNotFoundException {
        HashSet<LearnersList> hash = new HashSet<>();
        hash.add(new LearnersList("ronelle.s.nolasco", 1));
        hash.add(new LearnersList("mark.f.v.macandile", 1));
        hash.add(new LearnersList("nikolai.de.jesus", 1));


        assertEquals(hash, nL.readFile("test.csv", "existingLearners.csv", 2));

    }
    @Test
    public void writefileTest() throws FileNotFoundException {
        File file = new File("test.csv");
        Scanner scan = new Scanner(file);
        List<String> expected = new ArrayList<>();
        List<String> actualList = new ArrayList<>();
        while (scan.hasNext()){
            String scaned = scan.next();
            String[] listOfScaned = scaned.split(",");

            actualList.add(listOfScaned[0]+ "," +listOfScaned[1]);
        }

        expected.add("ronelle.s.nolasco,1");
        expected.add("mark.f.v.macandile,1");

        nL.readFile("test.csv", "existingLearners.csv", 10);

        assertEquals(expected, actualList);

    }
    }