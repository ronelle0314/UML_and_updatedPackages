package com.assessment.bootcampSpan;

import org.junit.Test;

import static org.junit.Assert.*;

public class BootcampSpanTest {

    @Test
    public void computeEndDateWithoutHolidayTest() {
        BootcampSpan bootcampSpan = new BootcampSpan();


        assertEquals("2019-02-14",  bootcampSpan.computeEndDate("2019-02-06", 7, "HOLIDAYS.csv", "quezoncity"));
    }

    @Test
    public void computeEndDateWithHolidayTest() {
        BootcampSpan bootcampSpan = new BootcampSpan();


        assertEquals("2018-11-12",  bootcampSpan.computeEndDate("2018-10-31", 7, "HOLIDAYS.csv", "cebu"));
    }

    @Test
    public void computeEndDateWithHolidayOnSpecificCityTest() {
        BootcampSpan bootcampSpan = new BootcampSpan();


        assertEquals("2019-08-14",  bootcampSpan.computeEndDate("2019-08-05", 7, "HOLIDAYS.csv", "taguig"));
    }


}