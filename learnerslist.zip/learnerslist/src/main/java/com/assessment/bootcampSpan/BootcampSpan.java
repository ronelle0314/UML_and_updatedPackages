package com.assessment.bootcampSpan;

import java.io.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class BootcampSpan {


    public String computeEndDate(String startDate, int noOfDays, String holiday, String city){
        SimpleDateFormat uniFormat = new SimpleDateFormat("yyyy-MM-dd");
        Calendar calender = Calendar.getInstance();

        List<Holidays> listOfHolidays = new ArrayList<>();

        String endDate = null;
        FileReader holidayFile;
        try {
            holidayFile = new FileReader(holiday);

            BufferedReader scanHoliday = new BufferedReader(holidayFile);

            int totalHolidays = 0;
            String holidayToRead;
            while ((holidayToRead = scanHoliday.readLine()) != null){

                String[] allHoliday = holidayToRead.split(",");

                try {
                    Date startDateToCompute = uniFormat.parse(startDate);

                    calender.setTime(startDateToCompute);

                    Date holidayToCompare = uniFormat.parse(allHoliday[0]);

                    listOfHolidays.add(new Holidays(holidayToCompare, allHoliday[1]));

                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }

            int counter = noOfDays;

            int totalWeekEnds = 0;

            while(counter > 0){
                int dayofWeek = calender.get(Calendar.DAY_OF_WEEK);
                if(!((dayofWeek==1) || (dayofWeek ==7))){
                    for(int i = 0; i<listOfHolidays.size(); i++){
                        if(listOfHolidays.get(i).getStartDate().equals(calender.getTime())){
                          if(listOfHolidays.get(i).getCity().equalsIgnoreCase("all")){
                              counter++;
                            }else if(listOfHolidays.get(i).getCity().equalsIgnoreCase(city)){
                              counter++;
                          }

                        }
                    }

                    counter--;
                }
                calender.add(Calendar.DAY_OF_MONTH, 1);

            }

            calender.add(Calendar.DAY_OF_MONTH, -1);


            endDate = uniFormat.format(calender.getTime());

            System.out.println("THE COMPUTED END DATE IS : " + endDate);

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return endDate;
    }
}
