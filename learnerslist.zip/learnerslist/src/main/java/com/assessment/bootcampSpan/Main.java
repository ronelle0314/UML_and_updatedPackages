package com.assessment.bootcampSpan;

public class Main {


    public static void main(String[] args) {
        BootcampSpan bootcampSpan = new BootcampSpan();
        bootcampSpan.computeEndDate("2019-08-05", 7, "HOLIDAYS.csv", "taguig");
    }
}
