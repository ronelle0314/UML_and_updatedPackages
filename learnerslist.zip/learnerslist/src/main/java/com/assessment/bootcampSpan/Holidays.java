package com.assessment.bootcampSpan;

import java.util.Date;

public class Holidays {
    private Date startDate;
    private String city;

    public Holidays(Date startDate, String city) {
        this.startDate = startDate;
        this.city = city;
    }

    public Date getStartDate() {
        return startDate;
    }

    public String getCity() {
        return city;
    }
}
