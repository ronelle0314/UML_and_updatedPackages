package com.assessment.demorandomizer;

import java.util.Objects;

public class LearnersList {
    private String EID;
    private String status;
    private int lateTime;
    private int timeForDemo;

    public LearnersList() {
    }

    public LearnersList(String EID, String status, int lateTime, int timeForDemo) {
        this.EID = EID;
        this.status = status;
        this.lateTime = lateTime;
        this.timeForDemo = timeForDemo;
    }

    public int getTimeForDemo() {
        return timeForDemo;
    }

    public LearnersList(String EID, String status, int lateTime) {
        this.EID = EID;
        this.status = status;
        this.lateTime = lateTime;
    }

    public String getEID() {
        return EID;
    }

    public String getStatus() {
        return status;
    }

    public int getLateTime() {
        return lateTime;
    }


    //uses only for junit testing for comparing 2 different instances of an object
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LearnersList)) return false;

        LearnersList that = (LearnersList) o;

        if (lateTime != that.lateTime) return false;
        if (timeForDemo != that.timeForDemo) return false;
        if (EID != null ? !EID.equals(that.EID) : that.EID != null) return false;
        return status != null ? status.equals(that.status) : that.status == null;
    }

    //uses only for junit testing for comparing 2 different instances of an object
    @Override
    public int hashCode() {
        int result = EID != null ? EID.hashCode() : 0;
        result = 31 * result + (status != null ? status.hashCode() : 0);
        result = 31 * result + lateTime;
        result = 31 * result + timeForDemo;
        return result;
    }
}
