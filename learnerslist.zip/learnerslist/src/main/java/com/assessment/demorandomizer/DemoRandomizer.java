package com.assessment.demorandomizer;

import java.io.*;
import java.util.*;

public class DemoRandomizer {

    private List<LearnersList> learnersLists = new ArrayList<LearnersList>();
    private List<LearnersList> listOfAbsentLearners = new ArrayList<LearnersList>();
    private List<LearnersList> listOfRandomizeLearners = new ArrayList<LearnersList>();

    public List<LearnersList> readFile(String demoList, int demoTime){


        FileReader newLearner;
        try {
            newLearner = new FileReader(demoList);
            String dataOfScanDemo;
            BufferedReader scanDemo = new BufferedReader(newLearner);
            while ((dataOfScanDemo = scanDemo.readLine()) != null){

                String[] listOfDemo = dataOfScanDemo.split(",");

                int lateTime = Integer.parseInt(listOfDemo[2]);
                if(listOfDemo[1].equalsIgnoreCase("present")) {
                    learnersLists.add(new LearnersList(listOfDemo[0], listOfDemo[1], lateTime));
                }else if (listOfDemo[1].equalsIgnoreCase("absent")) {
                    listOfAbsentLearners.add(new LearnersList(listOfDemo[0], listOfDemo[1], lateTime));
                }


            }

            if(learnersLists.size() <= 0){
                System.out.println("***No Present Learner***");
                newLearner.close();
                scanDemo.close();
                return learnersLists;
            }else {
                int demo = totalDemoTime(demoTime);
                for (LearnersList learn : learnersLists){
                    listOfRandomizeLearners.add(new LearnersList(learn.getEID(), learn.getStatus(), learn.getLateTime(), (demo - learn.getLateTime())));
                }
                print();
                newLearner.close();
                scanDemo.close();
            }

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        return listOfRandomizeLearners;
    }

    public int totalDemoTime (int demoTime){

        int minutes;
        minutes = demoTime * 60;

        int minPerLearner = minutes / learnersLists.size();

        return Math.round(minPerLearner);

    }

    public void print(){
        System.out.println("\t\t\t\t\t\t" +"***Randomize Demo Presentation***" + "\n\n");
        System.out.println("=PRESENT PARTICIPANTS=" + "\n");
        System.out.println("Position" + "\t\t\t\t" + "EID" + "\t\t\t\t\t" + "Late Time" + "\t\t\t" + "Total time for Demo" + "\n");
        Collections.shuffle(listOfRandomizeLearners);
            int count = 0;
            for (LearnersList learn : listOfRandomizeLearners){

                    count++;
                    System.out.println(count + "\t\t\t\t" + learn.getEID() + "\t\t\t\t" + learn.getLateTime() + "\t\t\t\t" + learn.getTimeForDemo());

            }
        System.out.println("\n" + "=ABSENT PARTICIPANTS=" + "\n");
        for (LearnersList learn : listOfAbsentLearners){

                System.out.println(learn.getEID() + "\t\t\t\t" + learn.getLateTime() + "\t\t\t\t" + learn.getStatus().toUpperCase());

        }


    }
}
