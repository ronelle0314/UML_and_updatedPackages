package com.assessment.demorandomizer;

public class Main {
    public static void main(String[] args) {
        DemoRandomizer random = new DemoRandomizer();
        random.readFile("demoList.csv", 4);


    }
}
