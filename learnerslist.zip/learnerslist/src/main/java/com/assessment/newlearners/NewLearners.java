package com.assessment.newlearners;

import java.io.*;
import java.util.*;

public class NewLearners {


    public HashSet<LearnersList> readFile(String newLearnerFile, String existingLearnerFile, int maximumSlots) throws FileNotFoundException {

        List<LearnersList> newlearnersList = new ArrayList<LearnersList>();

        List<LearnersList> existinglearnersList= new ArrayList<LearnersList>();

        File newLearner = new File(newLearnerFile);
        File existingLearner = new File (existingLearnerFile);

        HashSet<LearnersList> totalList = new HashSet<>();

        try {
            BufferedReader scanNew = new BufferedReader(new FileReader(newLearner));
            BufferedReader scanExisting = new BufferedReader(new FileReader(existingLearner));

            if (newLearner.getAbsoluteFile().length() > 0){

                String dataOfNewLearners;

                    while ((dataOfNewLearners = scanNew.readLine()) != null) {

                        String[] values = dataOfNewLearners.split(",");

                        int batch = Integer.parseInt(values[1]);

                        //trial.add(values[0] + " " + batch);
                        newlearnersList.add(new LearnersList(values[0], batch));
                    }
                String dataOfExistingLearners;

                    if(existingLearner.getAbsoluteFile().length() > 0){
                        while (( dataOfExistingLearners = scanExisting.readLine()) != null) {

                            String[] values = dataOfExistingLearners.split(",");

                            int batch = Integer.parseInt(values[1]);

                            //trial2.add(values[0]+ " " + batch);
                            existinglearnersList.add(new LearnersList(values[0], batch));
                        }

                        scanExisting.close();
                        scanNew.close();

                        for (LearnersList learns : newlearnersList) {
                            totalList.add(learns);
                        }
                        for (LearnersList learns : existinglearnersList) {
                            totalList.add(learns);
                        }
                        if (totalList.size() > maximumSlots) {
                            System.out.println("SORRY THE DATA EXCEEDED THE MAXIMUM SLOTS FOR LEARNERS");
                            return totalList;
                        } else {
                            writeFile(totalList);
                        }
                    }else{
                        for (LearnersList learns : newlearnersList) {
                            totalList.add(learns);
                        }
                        if (totalList.size() > maximumSlots) {
                            System.out.println("SORRY THE DATA EXCEEDED THE MAXIMUM SLOTS FOR LEARNERS");
                            return totalList;
                        } else {
                            writeFile(totalList);
                        }
                    }

                }
            else {
                    System.out.println("NO DATA TO READ FROM " + newLearnerFile);


                    scanExisting.close();
                    scanNew.close();
                 return null;
                }

        } catch (IOException e) {
            e.printStackTrace();
        }


//            for(int i = 0; i<newlearnersList.size(); i++){
//                if(!existinglearnersList.contains(newlearnersList.get(i))){
//                    existinglearnersList.add(newlearnersList.get(i));
//                }
//
//            }
//            for(String str: existinglearnersList){
//                System.out.println(str);
//            }


        return totalList;
    }

    public void writeFile(HashSet<LearnersList> listToWrite){
        String listLearners = "";
        try{
            String filename = "existingLearners.csv";
            for(LearnersList learnList : listToWrite) {
                listLearners += learnList.getEID() + "," + learnList.getBatchNo() + "\n";
            }
            File file = new File (filename);

            if(!file.exists()) {
                file.createNewFile();

                FileWriter fw = new FileWriter(file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(listLearners);
                bw.close();
                System.out.println("FILE CREATED");
            }else{


                file.delete();
                file.createNewFile();
                FileWriter fw = new FileWriter(file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(listLearners);
                bw.close();
                System.out.println("\n\n"+"SUCCESSFULLY UPDATED THE LIST OF EXISTING LEARNERS");
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
