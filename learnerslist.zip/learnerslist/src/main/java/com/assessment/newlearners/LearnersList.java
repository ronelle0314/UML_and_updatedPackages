package com.assessment.newlearners;

import java.util.Objects;

public class LearnersList {

    private String EID;
    private int batchNo;


    public LearnersList() {
    }

    public LearnersList(String EID, int batchNo) {
        this.EID = EID;
        this.batchNo = batchNo;
    }

    public String getEID() {
        return EID;
    }

    public int getBatchNo() {
        return batchNo;
    }

    //overrided method used to compare different instances of an object
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof LearnersList)) return false;
        LearnersList that = (LearnersList) o;
        return batchNo == that.batchNo &&
                Objects.equals(EID, that.EID);
    }

    //overrided method used to compare different instances of an object
    @Override
    public int hashCode() {
        return Objects.hash(EID, batchNo);
    }
}
