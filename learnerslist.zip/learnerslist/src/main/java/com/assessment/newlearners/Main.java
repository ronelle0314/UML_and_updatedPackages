package com.assessment.newlearners;

public class Main {
    public static void main(String[] args) throws Exception {
        NewLearners nL = new NewLearners();

        nL.readFile("newLearners.csv", "existingLearners.csv", 10);

    }

}
