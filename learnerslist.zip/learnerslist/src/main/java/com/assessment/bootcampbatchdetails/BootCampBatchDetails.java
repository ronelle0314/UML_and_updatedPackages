package com.assessment.bootcampbatchdetails;

import com.assessment.newlearners.LearnersList;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

public class BootCampBatchDetails {

    private int batchNumber;
    private String startDate;
    private String endDate;
    private int noOfLearners;
    private int noOfPassers;

    //static variable to use in any part of the class
    private static List<BootCampBatch> listOfBootcampBatch = new ArrayList<>();

    private List<BootCampBatch> listToWrite = new ArrayList<>();

    public BootCampBatchDetails() {
    }

    public BootCampBatchDetails(int batchNumber, String startDate, String endDate, int noOfLearners, int noOfPassers) {
        this.batchNumber = batchNumber;
        this.startDate = startDate;
        this.endDate = endDate;
        this.noOfLearners = noOfLearners;
        this.noOfPassers = noOfPassers;

        listOfBootcampBatch.add(new BootCampBatch(this.batchNumber,this.startDate,this.endDate,this.noOfLearners,this.noOfPassers));


    }

    public List<BootCampBatch> bootCampDetails(){


        for(BootCampBatch batchDetails : listOfBootcampBatch){
            if(batchDetails.getNoOfPassers() > batchDetails.getNoOfLearners()){
                System.out.println("Sorry Invalid Request Number of Passer is greater than number of learner in batch " + batchDetails.getBatchNumber());

                return listToWrite;
            }else if(batchDetails.getNoOfPassers() < 0) {
                System.out.println("ERROR: Number of Passers can't be negative at batch number " + batchDetails.getBatchNumber());

                return listToWrite;
            }else {
                float passingRate = (float) batchDetails.getNoOfPassers() / batchDetails.getNoOfLearners() * 100f;
                int noOfFailure = batchDetails.getNoOfLearners() - batchDetails.getNoOfPassers();
                batchDetails.setNoOfFailure(noOfFailure);
                float failureRate = (float) batchDetails.getNoOfFailure() / batchDetails.getNoOfLearners() * 100f;

                listToWrite.add(new BootCampBatch(batchDetails.getBatchNumber(), batchDetails.getStartDate(), batchDetails.getEndDate(), batchDetails.getNoOfLearners(), batchDetails.getNoOfPassers(), passingRate, noOfFailure, failureRate));
            }
        }

        return listToWrite;
    }


    public void createReport(List<BootCampBatch> details){
        String listOfBatch = "";
        try{
            String filename = "BootCampBatchDetails.csv";
            for(BootCampBatch batchDetails : details) {
                listOfBatch += batchDetails.getBatchNumber()+","+batchDetails.getStartDate()+","+batchDetails.getEndDate()+","+batchDetails.getNoOfLearners()+","+batchDetails.getNoOfPassers()+","+batchDetails.getPassingRate()+","+batchDetails.getNoOfFailure()+","+batchDetails.getFailureRate()+"\n";
            }
            File file = new File (filename);

            if(!file.exists()) {
                file.createNewFile();

                FileWriter fw = new FileWriter(file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(listOfBatch);
                bw.close();
                System.out.println("FILE CREATED");
            }else{

                file.delete();
                file.createNewFile();
                FileWriter fw = new FileWriter(file.getAbsoluteFile());
                BufferedWriter bw = new BufferedWriter(fw);
                bw.write(listOfBatch);
                bw.close();
                System.out.println("\n\n"+"SUCCESSFULLY UPDATED THE LIST OF BootCampBatchDetails");
            }
        }catch (IOException e){
            e.printStackTrace();
        }
    }
}
