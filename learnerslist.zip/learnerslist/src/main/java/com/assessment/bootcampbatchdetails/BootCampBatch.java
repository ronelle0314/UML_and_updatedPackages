package com.assessment.bootcampbatchdetails;

public class BootCampBatch {
    private int batchNumber;
    private String startDate;
    private String endDate;
    private int noOfLearners;
    private int noOfPassers;
    private float passingRate;
    private int noOfFailure;
    private float failureRate;

    public BootCampBatch(int batchNumber, String startDate, String endDate, int noOfLearners, int noOfPassers, float passingRate, int noOfFailure, float failureRate) {
        this.batchNumber = batchNumber;
        this.startDate = startDate;
        this.endDate = endDate;
        this.noOfLearners = noOfLearners;
        this.noOfPassers = noOfPassers;
        this.passingRate = passingRate;
        this.noOfFailure = noOfFailure;
        this.failureRate = failureRate;
    }

    public BootCampBatch(int batchNumber, String startDate, String endDate, int noOfLearners, int noOfPassers) {
        this.batchNumber = batchNumber;
        this.startDate = startDate;
        this.endDate = endDate;
        this.noOfLearners = noOfLearners;
        this.noOfPassers = noOfPassers;
    }

    public int getBatchNumber() {
        return batchNumber;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public int getNoOfLearners() {
        return noOfLearners;
    }

    public int getNoOfPassers() {
        return noOfPassers;
    }

    public float getPassingRate() {
        return passingRate;
    }

    public int getNoOfFailure() {
        return noOfFailure;
    }

    public float getFailureRate() {
        return failureRate;
    }

    public void setBatchNumber(int batchNumber) {
        this.batchNumber = batchNumber;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setNoOfLearners(int noOfLearners) {
        this.noOfLearners = noOfLearners;
    }

    public void setNoOfPassers(int noOfPassers) {
        this.noOfPassers = noOfPassers;
    }

    public void setPassingRate(float passingRate) {
        this.passingRate = passingRate;
    }

    public void setNoOfFailure(int noOfFailure) {
        this.noOfFailure = noOfFailure;
    }

    public void setFailureRate(float failureRate) {
        this.failureRate = failureRate;
    }

    //uses for junit testing to compare 2 different instances of an object
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof BootCampBatch)) return false;

        BootCampBatch that = (BootCampBatch) o;

        if (batchNumber != that.batchNumber) return false;
        if (noOfLearners != that.noOfLearners) return false;
        if (noOfPassers != that.noOfPassers) return false;
        if (Float.compare(that.passingRate, passingRate) != 0) return false;
        if (noOfFailure != that.noOfFailure) return false;
        if (Float.compare(that.failureRate, failureRate) != 0) return false;
        if (startDate != null ? !startDate.equals(that.startDate) : that.startDate != null) return false;
        return endDate != null ? endDate.equals(that.endDate) : that.endDate == null;
    }

    //uses for junit testing to compare 2 different instances of an object
    @Override
    public int hashCode() {
        int result = batchNumber;
        result = 31 * result + (startDate != null ? startDate.hashCode() : 0);
        result = 31 * result + (endDate != null ? endDate.hashCode() : 0);
        result = 31 * result + noOfLearners;
        result = 31 * result + noOfPassers;
        result = 31 * result + (passingRate != +0.0f ? Float.floatToIntBits(passingRate) : 0);
        result = 31 * result + noOfFailure;
        result = 31 * result + (failureRate != +0.0f ? Float.floatToIntBits(failureRate) : 0);
        return result;
    }
}
