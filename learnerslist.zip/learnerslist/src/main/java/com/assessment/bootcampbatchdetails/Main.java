package com.assessment.bootcampbatchdetails;

public class Main {
    public static void main(String[] args) {
        BootCampBatchDetails batch1 = new BootCampBatchDetails(1, "02/19/2019", "04/02/2019", 14, 4);
        BootCampBatchDetails batch2 = new BootCampBatchDetails(2, "02/19/2019", "04/02/2019", 20, 4);
        BootCampBatchDetails batch3 = new BootCampBatchDetails(3, "02/19/2019", "04/02/2019", 25, 4);
        BootCampBatchDetails batch4 = new BootCampBatchDetails(4, "02/19/2019", "04/02/2019", 30, 4);
        BootCampBatchDetails batch = new BootCampBatchDetails();


        batch.createReport(batch.bootCampDetails());
    }
}
