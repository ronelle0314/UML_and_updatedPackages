package com.assessment.learnerslist;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ActivityList act1 = new ActivityList("Concurrency");
        ActivityList act2 = new ActivityList("Collections");
        ActivityList act3 = new ActivityList("Naming Conventions");
        ActivityList act4 = new ActivityList("Junit");
        ActivityList act5 = new ActivityList("Termination");




        ActivityList.addToList();


    }

}

