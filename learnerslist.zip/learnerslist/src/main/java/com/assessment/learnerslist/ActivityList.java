package com.assessment.learnerslist;


import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ActivityList{
    private String activity;

    //static variable to use in any part of the class
    private static List<String> actList = new ArrayList<String>();

    private static List<String> chosenActivity = new ArrayList<String>();

    private static LearnersList learn = new LearnersList("Ronelle", 10);

    //uses in junit testing to test the content of the list
    public List<String> getActList() {
        return actList;
    }

    //uses in junit testing to test the content of the list
    public List<String> getChosenActivity() {
        return chosenActivity;
    }

    public ActivityList(String activity) {
        this.activity = activity;
        add();
    }

    public void add(){
            actList.add(this.activity);
    }

    public static void addToList(){

        Scanner sc = new Scanner(System.in);
        System.out.println("LIST OF ACTIVITIES: " + actList);

        System.out.println("\n" + "Choose activity from 1 to 5 press 0 to terminate and 9 to view result");

        boolean flag = true;

        while (flag){
            int act = sc.nextInt();
            switch (act){

                case 1:
                    if(chosenActivity.contains(actList.get(0)) && chosenActivity.contains(actList.get(1)) && chosenActivity.contains(actList.get(2)) && chosenActivity.contains(actList.get(3)) && chosenActivity.contains(actList.get(4)))
                    {
                        System.out.println("All Activities Added" + "\n");
                        break;
                    }
                     if(chosenActivity.contains(actList.get(0))){
                         System.out.println("Activity Already added" + "\n");
                         System.out.println("Current Activities: " + chosenActivity + "\n");
                         System.out.println("Choose another? " + actList + "\n");
                         System.out.println("\n" + "Choose activity from 1 to 5 press 0 to terminate and 9 to view result");
                            break;
                     }
                     else {
                    chosenActivity.add(actList.get(0));
                    System.out.println("Current Activities: " + chosenActivity + "\n");
                    System.out.println("Choose another? " + actList + "\n");
                    break;}

                case 2:
                    if(chosenActivity.contains(actList.get(0)) && chosenActivity.contains(actList.get(1)) && chosenActivity.contains(actList.get(2)) && chosenActivity.contains(actList.get(3)) && chosenActivity.contains(actList.get(4)))
                    {
                        System.out.println("All Activities Added" + "\n");
                        break;
                    }
                    if(chosenActivity.contains(actList.get(1))){
                        System.out.println("Activity Already added" + "\n");
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        System.out.println("\n" + "Choose activity from 1 to 5 press 0 to terminate and 9 to view result");
                        break;
                    }else {
                        chosenActivity.add(actList.get(1));
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        break;
                    }
                case 3:
                    if(chosenActivity.contains(actList.get(0)) && chosenActivity.contains(actList.get(1)) && chosenActivity.contains(actList.get(2)) && chosenActivity.contains(actList.get(3)) && chosenActivity.contains(actList.get(4)))
                    {
                        System.out.println("All Activities Added" + "\n");
                        break;
                    }
                    if(chosenActivity.contains(actList.get(2))){
                        System.out.println("Activity Already added" + "\n");
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        System.out.println("\n" + "Choose activity from 1 to 5 press 0 to terminate and 9 to view result");
                        break;
                    }else {
                        chosenActivity.add(actList.get(2));
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        break;
                    }
                case 4:
                    if(chosenActivity.contains(actList.get(0)) && chosenActivity.contains(actList.get(1)) && chosenActivity.contains(actList.get(2)) && chosenActivity.contains(actList.get(3)) && chosenActivity.contains(actList.get(4)))
                    {
                        System.out.println("All Activities Added" + "\n");
                        break;
                    }
                    if(chosenActivity.contains(actList.get(3))){
                        System.out.println("Activity Already added" + "\n");
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        System.out.println("\n" + "Choose activity from 1 to 5 press 0 to terminate and 9 to view result");
                        break;
                    }else {
                        chosenActivity.add(actList.get(3));
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        break;
                    }
                case 5:
                    if(chosenActivity.contains(actList.get(0)) && chosenActivity.contains(actList.get(1)) && chosenActivity.contains(actList.get(2)) && chosenActivity.contains(actList.get(3)) && chosenActivity.contains(actList.get(4)))
                    {
                        System.out.println("All Activities Added" + "\n");
                        break;
                    }
                    if(chosenActivity.contains(actList.get(4))){
                        System.out.println("Activity Already added" + "\n");
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        System.out.println("\n" + "Choose activity from 1 to 5 press 0 to terminate and 9 to view result");
                        break;
                    }else {
                        chosenActivity.add(actList.get(4));
                        System.out.println("Current Activities: " + chosenActivity + "\n");
                        System.out.println("Choose another? " + actList + "\n");
                        break;
                    }
                case 0:
                    flag = false;
                    break;
                case 9:
                    print();
                    flag = false;
                    break;


            }
        }

    }
    public static int totalHours(int totalHours){
        int minutes;
        minutes = totalHours * 60;

        int minPerAct = minutes / chosenActivity.size();

        return Math.round(minPerAct);
    }

    public static void print() {
        if (chosenActivity.size() == 0) {
            System.out.println("** NO TOPICS CHOSEN INVALID DATA **");
        } else {
            System.out.println("Name: " + learn.getName() + "\n");
            System.out.println("-------------------------");
            System.out.println("Current Activities: ");
            for (String cuurAct : chosenActivity) {
                System.out.println("*" + cuurAct);
            }
            System.out.println("-------------------------");
            System.out.println("Total Minutes Per Activity: " + totalHours(learn.getHours()));
        }
    }
}
